﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

public class Employee
{
    public int EmployeeID { get; set; }
    public string EmployeeName { get; set; }
    public string Designation { get; set; }
    public DateTime JoiningDate { get; set; }
    public string DepartmentName { get; set; }

}
class EmployeeData
{   
    public ArrayList EmployeeInfo { get; set; }
    public void read(Employee e)
    {
        Console.WriteLine("Enter Employee Id: ");
        e.EmployeeID = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter Employee Name: ");
        e.EmployeeName = Console.ReadLine();
        Console.WriteLine("Enter Designation: ");
        e.Designation = Console.ReadLine();
        Console.WriteLine("Enter Joining Date: ");
        e.JoiningDate = Convert.ToDateTime(Console.ReadLine());
        Console.WriteLine("Enter Department Name: ");
        e.DepartmentName = Console.ReadLine();       
    }
}
class MainUser
{
    public static void Main(string[] args)
    {
        Employee e1 = new Employee();
        EmployeeData d = new EmployeeData();        
        d.read(e1);
        ArrayList arr = new ArrayList();
        arr.Add(e1.EmployeeID.ToString());
        arr.Add(e1.EmployeeName);
        arr.Add(e1.Designation);
        arr.Add(e1.JoiningDate.ToString());
        arr.Add(e1.DepartmentName);
        Employee e2 = new Employee();        
        d.read(e2);
        arr.Add(e2.EmployeeID.ToString());
        arr.Add(e2.EmployeeName);
        arr.Add(e2.Designation);
        arr.Add(e2.JoiningDate.ToString());
        arr.Add(e2.DepartmentName);
        d.EmployeeInfo = arr;
        string path = @"D:\Studies\wipro_pjp\Collections and searching\Test.csv";       
        string delimiter = ",";
        string text = "";
        int i = 1;
        foreach (string var in d.EmployeeInfo)
        {
            if (i == 1)
            {
                text = text + "Employee Id: " + var + delimiter;
                i++;
            }
            else if (i == 2)
            {
                text = text + "Employee Name: " + var + delimiter;
                i++;
            }
            else if (i == 3)
            {
                text = text + "Designation: " + var + delimiter;
                i++;
            }
            else if (i == 4)
            {
                text = text + "Joining Date: " + var + delimiter;
                i++;
            }
            else
            {
                text = text + "Department Name: " + var + delimiter;
                i = 1;
            }            
        }
        text = text + Environment.NewLine;
        if (!File.Exists(path)){
            
            File.WriteAllText(path, text);
        }    
        else
        File.AppendAllText(path, text);
        Console.ReadKey();
    }
}