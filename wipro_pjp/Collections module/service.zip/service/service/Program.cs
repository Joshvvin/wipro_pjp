﻿using System;
using System.Collections;
namespace service{
    
    class ServiceToken
    {
        public int TokenID { get; set; }
        public string position { get; set; }
        public DateTime TicketDateTime { get; set; }
        public string Status { get; set; }
        public ServiceToken()
        {
            TokenID++;
            position = "account";
            TicketDateTime = DateTime.Now;
            Status = "Incomplete";
        }
    }
    class TicketManager
    {
       public Queue q { get; set; }
       public void GenerateServiceToken()
        {
            ServiceToken st = new ServiceToken();
            Queue tem = new Queue();
            tem.Enqueue(st.TokenID);
            tem.Enqueue(st.position);
            tem.Enqueue(st.TicketDateTime);
            tem.Enqueue(st.Status);
            q = tem;
        }
        public void GetNextToken()
        {
            Console.WriteLine("Next available token is: "+q.Peek());
        }
        public void UpdateToken(int token)
        {
            foreach(ServiceToken s in q)
            {
                if (s.TokenID == token)
                {
                    s.Status = "Completed";
                    break;
                }
            }
        }
        public void SkipToken()
        {
            for (int i = 0; i < 4; i++)
            {
                q.Dequeue();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*********************Token Managment System************************\n");
            Console.WriteLine("1. Create Token\n2. Get Next Token\n3. Update Token\n4. Skip Token\n5. List all the tokens\n6. Exit");
            bool f = true;
            TicketManager tm = new TicketManager();
            
            while (f)
            {
                Console.WriteLine("Enter the choice :");
                int ch = int.Parse(Console.ReadLine());
                if (ch == 1)
                {
                    tm.GenerateServiceToken();                    
                }
                else if (ch == 2)
                {
                    tm.GetNextToken();
                }
                else if (ch == 3)
                {
                    Console.WriteLine("Enter the Token ID :");
                    int t = int.Parse(Console.ReadLine());
                    tm.UpdateToken(t);
                }
                else if (ch == 4)
                {
                    tm.SkipToken();
                }
                else if (ch == 5)
                {
                    int i = 1;
                    foreach (var s in tm.q)
                    {
                        if (i == 1)
                        {
                            Console.WriteLine("Token ID : " + s);
                            i++;
                        }
                        else if (i == 2)
                        {
                            Console.WriteLine("Position : " + s);
                            i++;
                        }
                        else if (i == 3)
                        {
                            Console.WriteLine("Ticket Date Time : " + s);
                            i++;
                        }
                        else if (i == 4)
                        {
                            Console.WriteLine("Status : " + s);
                            i = 1;
                        }
                    }
                }
                else
                {
                    f = false;
                }
            }
        }
    }
}
