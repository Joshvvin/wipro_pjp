﻿using System;
namespace Math
{
    class Program
    {
        public static int add(int a,int b)
        {
            return (a + b);
        }
        public static int add(int a,int b,int c)
        {
            return a + b + c;
        }
        public static int mul(int a, int b)
        {
            return a *b;
        }
        public static int mul(int a, int b, int c)
        {
            return a *b* c;
        }
        public static int sub(int a, int b)
        {
            return (a - b);
        }
        public static int sub(int a, int b,int c)
        {
            return a-b-c;
        }
        public static int div(int a, int b)
        {
            return a / b;
        }
        public static int div(int a, int b, int c)
        {
            return a / b / c;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the first number: ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the second number: ");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the third number: ");
            int c = int.Parse(Console.ReadLine());
            Console.WriteLine(add(a,b));
            Console.WriteLine(add(a,b,c));
            Console.WriteLine(mul(a, b));
            Console.WriteLine(mul(a,b,c));
            Console.WriteLine(sub(a,b));
            Console.WriteLine(sub(a,b,c));
            Console.WriteLine(div(a,b));
            Console.WriteLine(div(a,b,c));
        }
    }
}
