﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Employee
{
    public interface Ipayable
    {
        void Calculatepay();
    }
}
