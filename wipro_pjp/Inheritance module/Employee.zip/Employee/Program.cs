﻿using System;
using System.Collections.Generic;
namespace Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Person p = new Person();
            Console.WriteLine("Enter the first name: ");
            p.Firstname = Console.ReadLine();
            Console.WriteLine("Enter the last name: ");
            p.Lastname = Console.ReadLine();
            Console.WriteLine("1. HourlyEmployee\n2. PermanentEmployee\nEnter the choice :");
            int ch = int.Parse(Console.ReadLine());
            if (ch == 1)
            {
                hourly h1 = new hourly();
                Console.WriteLine("Enter the hours worked: ");
                h1.HoursWorked = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter the pay per hour: ");
                h1.PayPerHour = Convert.ToDouble(Console.ReadLine());                
                h1.Calculatepay();
            }
            else if (ch == 2)
            {               
                permanent P1 = new permanent();
                P1.Calculatepay();
            }    
            
            
        }
    }
}
