﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Employee
{
    class permanent: Person, Ipayable
    {
        double HRA = 0, DA = 0, Tax = 0, Netpay=0, Total = 0;
        public double hra
        {
            get { return HRA; }
            set { HRA = value; }
        }
        public double da
        {
            get { return DA; }
            set { DA = value; }
        }
        public double tax
        {
            get { return Tax; }
            set { Tax = value; }
        }
        public double netpay
        {
            get { return Netpay; }
            set { Netpay = value; }
        }
        public double total
        {
            get { return Total; }
            set { Total = value; }
        }
        public void Calculatepay()
        {
            Console.WriteLine("Enter Base salary:  ");
            double bas = Convert.ToDouble(Console.ReadLine());
            this.hra = 0.15 * bas;
            this.da = 0.10 * bas;
            this.total = bas + this.da + this.hra;
            this.tax = 0.08 * this.total;
            this.netpay = this.total - this.tax;
            Console.WriteLine("Net Pay is: " + netpay);
        }

    }

}
