﻿using System;
using System.IO;
using System.Text;

namespace filehandling
{
    class Program
    {
        class filew
        {
            public void writef()
            {
                try
                {
                    string path = @"D:\Studies\file.txt";

                    using (FileStream fs = File.Create(path)) { fs.Close(); }

                    using (StreamWriter sw = new StreamWriter(path))
                    {
                        Console.WriteLine("Enter the Text that you want to write on File");
                        string str = Console.ReadLine();
                        sw.WriteLine(str);
                        sw.Flush();
                        sw.Close();
                        
                    }
                    
                }
                catch (Exception Ex)
                {
                    Console.WriteLine(Ex.ToString());
                }
            }
        }
        static void Main(string[] args)
        {
            filew fw = new filew();
            fw.writef();
        }
    }
}
