﻿using System;

namespace Area
{
    class Program
    {
        public static void area(float a)
        {
            double area = 3.14 * a * a;
            Console.WriteLine("{0}",area);
        }
        public static void area(int l,int b)
        {
            double area = l*b;
            Console.WriteLine(area);
        }
        public static void area(float h, float b)
        {
            double area = h * b/2;
            Console.WriteLine(area);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the radius of circle: ");
            float r = float.Parse(Console.ReadLine());
            Console.WriteLine("Area of circle: ");
            area(r);
            Console.WriteLine("Enter the length of rectangle: ");
            int l = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the breadth of rectangle: ");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Area of rectangle: ");
            area(l,b);
            Console.WriteLine("Enter the height of traingle: ");
            float h = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter the breadth of traingle: ");
            float br = float.Parse(Console.ReadLine());
            Console.WriteLine("Area of rectangle: ");
            area(h,br);

        }
    }

}
