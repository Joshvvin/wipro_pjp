select SUBSTRING(addressline1,1,10) from address;
