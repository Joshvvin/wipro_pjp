update demoaddress
set addressline2 = 'N/A'
where addressline2 = 'null';