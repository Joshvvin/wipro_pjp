delete from democustomer
where lastname like 'S%';
	