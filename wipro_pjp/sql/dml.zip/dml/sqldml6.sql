insert into demoproduct (productid, name, color, standardcost, listprice, size, weight) values(101, 'pencilbox', 'blue', 150, 165, '10', 1.5);
insert into demoproduct (productid, name, color, standardcost, listprice, size, weight) values(102, 'scissors', 'black', 25, 35, '8', 0.75);
insert into demoproduct (productid, name, color, standardcost, listprice, size, weight) values(103, 'book', 'white', 35, 45, '9', 1.0);
insert into demoproduct (productid, name, color, standardcost, listprice, size, weight) values(104, 'pen', 'blue', 10, 15, '8', 0.25);
insert into demoproduct (productid, name, color, standardcost, listprice, size, weight) values(105, 'pencil', 'grey', 1, 2, '10', 0.15);
