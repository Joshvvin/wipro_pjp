select * from salesorderheader sh join salesorderdetail sd
on sh.salesorderid=sd.productid;