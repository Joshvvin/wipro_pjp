select modifieddata from person
union
select hiredate from employee;